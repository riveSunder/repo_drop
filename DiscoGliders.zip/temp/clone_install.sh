git clone --shallow-since 2022-08-28 git@github.com:riveSunder/yuca.git
cd yuca 
git checkout 53809de1ced462f4b6bc517e388f5ec116c43901
pip install -e .
