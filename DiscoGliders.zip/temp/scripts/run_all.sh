# First ensure virtual environment is activated

python scripts/glaberish_exp.py
python scripts/lenia_exp.py
python scripts/nca_exp.py
python scripts/smoothlife_exp.py
#python scripts/uskate_exp_NOT_USED.py
