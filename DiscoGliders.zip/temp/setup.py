from setuptools import setup


setup(\
        name="DiscoGliders", \
        packages=["disco"], \
        version = "0.0", \
        description = "Investigating discretization effects on gliders in (Dis)Continuous Cellular Automata", \
    )


