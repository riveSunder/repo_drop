# Glider gallery

## U-Skate World

<div align="center">
<img src="./assets/uskate_4.gif">
</div>

## SmoothLife

<div align="center">
<img src="./assets/smoothlife_4.gif">
</div>

## Lenia

<div align="center">
<img src="./assets/lenia_4.gif">
</div>

## Glaberish

<div align="center">
<img src="./assets/glaberish_4.gif">
</div>

## Neural Cellular Automata

<div align="center">
<img src="./assets/nca_neurorbium000.gif">
<img src="./assets/nca_neurosingle_glider000.gif">
<img src="./assets/nca_neurosynorbium000.gif">
<img src="./assets/nca_neurowobble_glider000.gif">
</div>

## Adam automaton (Adorbium)

<div align="center">
<img src="./assets/adorbium_4.gif">
</div>
